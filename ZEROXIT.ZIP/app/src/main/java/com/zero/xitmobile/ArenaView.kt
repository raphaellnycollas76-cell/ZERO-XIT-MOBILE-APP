package com.zero.xitmobile

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.view.MotionEvent
import android.view.View
import kotlin.random.Random

class ArenaView(context: Context) : View(context) {
    var showEsp = true
    var fovRadius = 120f
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private data class Target(var x: Float, var y: Float, var w: Float, var h: Float, val label: String)
    private val targets = mutableListOf<Target>()

    init {
        setBackgroundColor(0xFF171820.toInt())
        resetTargets()
    }

    fun resetTargets() {
        targets.clear()
        targets.add(Target(.22f, .28f, .12f, .24f, "BOT 01"))
        targets.add(Target(.62f, .22f, .13f, .27f, "BOT 02"))
        targets.add(Target(.42f, .58f, .11f, .22f, "BOT 03"))
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        val sx = width.toFloat()
        val sy = height.toFloat()

        paint.color = 0xFF252936.toInt()
        paint.style = Paint.Style.FILL
        canvas.drawRoundRect(RectF(18f, 18f, sx - 18f, sy - 18f), 18f, 18f, paint)

        paint.color = 0xFF343A49.toInt()
        paint.strokeWidth = 2f
        paint.style = Paint.Style.STROKE
        for (i in 1..3) {
            val y = sy * i / 4f
            canvas.drawLine(28f, y, sx - 28f, y, paint)
        }

        // Visual FOV indicator centered in the local training arena.
        paint.color = 0x66FF4055
        paint.strokeWidth = 3f
        paint.style = Paint.Style.STROKE
        canvas.drawCircle(sx / 2f, sy * .52f, fovRadius.coerceAtMost(sx * .42f), paint)

        targets.forEach { t ->
            val left = t.x * sx
            val top = t.y * sy
            val right = left + t.w * sx
            val bottom = top + t.h * sy

            paint.style = Paint.Style.FILL
            paint.color = 0xFFB7C0D2.toInt()
            canvas.drawCircle((left + right) / 2f, top + 13f, 11f, paint)
            canvas.drawRoundRect(RectF(left + 5f, top + 27f, right - 5f, bottom), 8f, 8f, paint)

            if (showEsp) {
                paint.style = Paint.Style.STROKE
                paint.strokeWidth = 3f
                paint.color = 0xFFFF4055.toInt()
                canvas.drawRect(left, top, right, bottom, paint)

                paint.style = Paint.Style.FILL
                paint.textSize = 28f
                paint.color = 0xFFFFFFFF.toInt()
                canvas.drawText(t.label, left - 2f, top - 10f, paint)

                paint.color = 0xFFFF4055.toInt()
                canvas.drawRect(left, bottom + 7f, right, bottom + 12f, paint)
            }
        }

        paint.style = Paint.Style.FILL
        paint.textSize = 25f
        paint.color = 0xFFCAD0DC.toInt()
        canvas.drawText("ARENA DE TREINO", 30f, sy - 35f, paint)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        if (event.action == MotionEvent.ACTION_DOWN) {
            // Tap a target to move it within this local demo scene.
            targets.minByOrNull { t ->
                val cx = (t.x + t.w / 2f) * width
                val cy = (t.y + t.h / 2f) * height
                (cx - event.x) * (cx - event.x) + (cy - event.y) * (cy - event.y)
            }?.let { target ->
                target.x = Random.nextFloat() * .72f + .08f
                target.y = Random.nextFloat() * .58f + .12f
                invalidate()
            }
            return true
        }
        return true
    }
}
