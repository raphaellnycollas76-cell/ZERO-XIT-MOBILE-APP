plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}
android {
    namespace = "com.zero.xitmobile"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.zero.xitmobile"
        minSdk = 23
        targetSdk = 35
        versionCode = 1
        versionName = "1.0"
    }
}
