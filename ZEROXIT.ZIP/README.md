# ZERO XIT MOBILE

Projeto Android nativo em Kotlin. O aplicativo contém uma arena local com alvos simulados, ESP visual (caixas e rótulos) e um indicador circular AimFOV.

## Escopo funcional
- ESP desenhado sobre entidades simuladas dentro da própria tela do aplicativo.
- Chave para ligar/desligar o ESP.
- Controle de raio do indicador AimFOV.
- Toque na arena para reposicionar um alvo de teste.
- Não acessa memória, processos, arquivos ou tráfego do Free Fire e não desenha sobre outros aplicativos.

## Gerar o APK
1. Instale o Android Studio (versão atual) e um JDK 17.
2. Abra a pasta `ZERO_XIT_MOBILE` no Android Studio.
3. Aguarde a sincronização do Gradle.
4. Selecione **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
5. O APK de depuração será gerado em `app/build/outputs/apk/debug/app-debug.apk`.

Para um APK de distribuição, use **Build > Generate Signed Bundle / APK** e crie uma chave de assinatura própria.

## Requisitos
- Android Studio com suporte a Android Gradle Plugin 8.7.3.
- Android SDK Platform 35.
- JDK 17.
