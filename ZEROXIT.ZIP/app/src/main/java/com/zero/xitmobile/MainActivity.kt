package com.zero.xitmobile

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private lateinit var arena: ArenaView
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(12, 12, 16)
        window.navigationBarColor = Color.rgb(12, 12, 16)

        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(18, 22, 18, 18)
            setBackgroundColor(Color.rgb(12, 12, 16))
        }

        val title = TextView(this).apply {
            text = "ZERO XIT MOBILE"
            textSize = 24f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            letterSpacing = 0.12f
        }
        page.addView(title, LinearLayout.LayoutParams(-1, 54))

        status = TextView(this).apply {
            text = "DEMO ARENA  •  ESP LOCAL"
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(255, 70, 80))
        }
        page.addView(status, LinearLayout.LayoutParams(-1, 30))

        arena = ArenaView(this)
        page.addView(arena, LinearLayout.LayoutParams(-1, 0, 1f))

        val esp = Switch(this).apply {
            text = "ESP visual (caixas e marcadores)"
            setTextColor(Color.WHITE)
            isChecked = true
            setOnCheckedChangeListener { _, checked ->
                arena.showEsp = checked
                arena.invalidate()
                status.text = if (checked) "ESP ATIVO • CENA DE TESTE" else "ESP DESATIVADO"
            }
        }
        page.addView(esp, LinearLayout.LayoutParams(-1, 52))

        val fovLabel = TextView(this).apply {
            text = "AimFOV visual: 120"
            textSize = 14f
            setTextColor(Color.WHITE)
        }
        page.addView(fovLabel)

        val fov = SeekBar(this).apply {
            max = 250
            progress = 120
            setOnSeekBarChangeListener(object : android.widget.SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(seekBar: SeekBar?, value: Int, fromUser: Boolean) {
                    val v = value.coerceAtLeast(10)
                    fovLabel.text = "AimFOV visual: $v"
                    arena.fovRadius = v.toFloat()
                    arena.invalidate()
                }
                override fun onStartTrackingTouch(seekBar: SeekBar?) {}
                override fun onStopTrackingTouch(seekBar: SeekBar?) {}
            })
        }
        page.addView(fov, LinearLayout.LayoutParams(-1, 44))

        val reset = Button(this).apply {
            text = "REINICIAR CENA DE TESTE"
            setTextColor(Color.WHITE)
            setBackgroundColor(Color.rgb(150, 25, 38))
            setOnClickListener { arena.resetTargets() }
        }
        page.addView(reset, LinearLayout.LayoutParams(-1, 52))

        val note = TextView(this).apply {
            text = "O ESP desenha somente os alvos simulados nesta arena local."
            textSize = 11f
            setTextColor(Color.LTGRAY)
            gravity = Gravity.CENTER
            setPadding(0, 10, 0, 0)
        }
        page.addView(note, LinearLayout.LayoutParams(-1, 42))

        setContentView(page)
    }
}
